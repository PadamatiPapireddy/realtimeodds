package com.realtimeodds.service.api;

public interface RealTimeOdd {
	

}
