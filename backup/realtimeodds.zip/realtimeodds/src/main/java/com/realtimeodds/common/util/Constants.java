package com.realtimeodds.common.util;

public class Constants {
	
	protected Constants() {
		super();
	}
	public static final String TAGS = "MATCH" ;
	public static final String url = "https://eu-offering.kambicdn.org/offering/v2018/ubse/event/live/open.json";

}
