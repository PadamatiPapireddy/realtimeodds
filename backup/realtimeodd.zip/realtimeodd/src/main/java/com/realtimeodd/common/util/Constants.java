package com.realtimeodd.common.util;

public class Constants {
	
	public static final String TAGS = "MATCH" ;
	public static final String URL = "https://eu-offering.kambicdn.org/offering/v2018/ubse/event/live/open.json";
	public static final long TIME_INTERVAL = 10000;

}
